const express = require("express");
const connection = require("../connection");
const router = express.Router();

const jwt = require("jsonwebtoken");
const nodemailer = require("nodemailer");
require("dotenv").config;
var auth = require("../services/authentication");
var checkRole = require("../services/checkRole");
router.post("/signup", (req, res) => {
  let users = req.body;
  query = "SELECT email, password, role, status FROM users WHERE email=?";
  connection.query(query, [users.email], (err, results) => {
    if (!err) {
      if (results.length <= 0) {
        query =
          "insert into users (contact_number, email, name, password, role, status) values (?,?,?,?,?,?)";
        connection.query(
          query,
          [
            users.contact_number,
            users.email,
            users.name,
            users.password,
            "user",
            "false",
          ],
          (err, res) => {
            if (!err) {
              return res
                .status(200)
                .json({ message: "Successfully Registered" });
            } else {
              return res.status(500).json(err);
            }
          }
        );
      } else {
        return res.status(400).json({ message: "Emaily Already Exist." });
      }
    } else {
      return res.status(500).json(err);
    }
  });
});

router.post("/login", (req, res) => {
  const users = req.body;
  query = "select email,password,role,status from users where email=?";
  connection.query(query, [users.email], (err, results) => {
    if (!err) {
      if (results.length <= 0 || results[0].password != users.password) {
        return res
          .status(401)
          .json({ message: "Incorrect Username or password" });
      } else if (results[0].status === "false") {
        return res.status(401).json({ message: "wait for Admin Aproval" });
      } else if (results[0].password == users.password) {
        const response = { email: results[0].email, role: results[0].role };
        const accessToken = jwt.sign(response, process.env.ACCESS_TOKEN, {
          expiresIn: "8h",
        });
        res.status(200).json({ token: accessToken });
      } else {
        return res
          .status(400)
          .json({ message: "Something went wrong.Please try again later" });
      }
    } else {
      return res.status(500).json(err);
    }
  });
});

var transporter = nodemailer.createTransport({
  service: "gmail",
  auth: {
    user: process.env.EMAIL,
    pass: process.env.PASSWORD,
  },
});

router.post("/forgotpassword", (req, res) => {
  const users = req.body;
  query = "select email,password from users where email=?";
  connection.query(query, [users.email], (err, results) => {
    if (!err) {
      if (results.length <= 0) {
        return res
          .status(200)
          .json({ message: "Password sent sucessfully to your email." });
      } else {
        var mailOptions = {
          from: process.env.EMAIL,
          to: results[0].email,
          subject: "Password by Restaurant App",
          html:
            "<p><b> Your Login details for Restaurant App</b> <br><b>Email:</b>" +
            results[0].email +
            "<br><b>Password: </b>" +
            results[0].password +
            '<br><a href="http://localhost:4200/"> Click here to login</a></p>',
        };
        transporter.sendMail(mailOptions, function (error, info) {
          if (error) {
            console.log(error);
          } else {
            console.log("email sent:" + info.response);
          }
        });
        return res
          .status(200)
          .json({ message: "Password sent successfully to your email." });
      }
    } else {
      return res.status(500).json(err);
    }
  });
});

router.get("/get", auth.authenticateToken, (req, res) => {
  var query =
    "select id,name,email,contact_number, status from users where role='user'";
  connection.query(query, (err, results) => {
    if (!err) {
      return res.status(200).json(results);
    } else {
      return res.status(500).json(err);
    }
  });
});

router.patch("/update", auth.authenticateToken, (req, res) => {
  let users = req.body;
  var query = "update users set status=? where id=?";
  connection.query(query, [users.status, users.id], (err, results) => {
    if (!err) {
      if (results.affectedRows == 0) {
        return res.status(404).json({ message: "Users id does not exist" });
      }
      return res.status(200).json({ message: "Users Updated Successfully" });
    } else {
      return res.status(500).json(err);
    }
  });
});

router.get("/checkTocken", auth.authenticateToken, (req, res) => {
  return res.status(200).json({ message: "true" });
});

router.post("/changerPassword", (req, res) => {
  const users = req.body;
  const email = res.locals.email;
  var query = "select * from users where email=? and password=?";
  connection.query(query, [email, users.oldPassword], (err, results) => {
    if (!err) {
      if (results.length <= 0) {
        return res.status(400).json({ message: "Incorrect Old Passwoed" });
      } else if (results[0].password == users.oldPassword) {
        query = "update users set password=? where email=?";
        connection.query(query, [users.newPassword, email], (err, results) => {
          if (!err) {
            return res
              .status(200)
              .json({ message: "Password Updated Succesfully." });
          } else {
            return res.status(500).json(err);
          }
        });
      } else {
        return res
          .status(400)
          .json({ message: "Something went wrong. Please try again later" });
      }
    } else {
      return res.status(500).json(err);
    }
  });
});

module.exports = router;
